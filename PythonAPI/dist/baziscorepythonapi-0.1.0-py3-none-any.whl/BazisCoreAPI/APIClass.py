import string
import sys
import os
from pythonnet import load

load("coreclr")
import clr

# Add the directory containing your DLL to the system path
startDir = os.getcwd()

os.chdir('.\src\BazisCoreAPI\libs')
dll_Dir = os.getcwd()
sys.path.append(dll_Dir)

os.chdir(startDir)

# Add a reference to the assembly (use the name of the DLL without the extension)
clr.AddReference("TestLib")

# Import the specific namespace and class
from TestLib import Class1


class APIClass:
    def __init__(self):
        self.csClassInstance = Class1()


    def Set_field(self, string):
        self.csClassInstance.SetField(string)


    def Get_field(self):
        return self.csClassInstance.GetField()


    def Get_double_field(self):
        return self.csClassInstance.GetDoubleFiled()


    def Get_SQRT(self, num):
        return self.csClassInstance.GetSqrt(num)


    def Get_double(self, num):
        return self.csClassInstance.GetDoubleSum(num)
