import sys
import os
from pythonnet import load

load("coreclr")
import clr

dll_folder = os.path.join(os.path.dirname(__file__), 'libs')
sys.path.append(dll_folder)

clr.AddReference("TestLib")

from TestLib import Class1